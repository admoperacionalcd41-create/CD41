import React, { useEffect, useMemo, useState } from 'react';
import { LogIn, LogOut, CheckCircle2, LocateFixed, MapPinOff, Clock, MapPin, Undo2, MessageSquareText, History, ChevronDown, ChevronUp, ArrowLeft, Search, User } from 'lucide-react';
import { useApp } from '../../context/AppContext.jsx';
import { formatarHora, formatarData, formatarDuracao, paraDataHoraLocalInput, deDataHoraLocalInput, eHoje } from '../../utils/dateHelpers';
import TipoCargaBadge from '../Shared/TipoCargaBadge.jsx';
import { lojaPassaFiltroTipoCarga } from '../../utils/tipoCarga';
import { calcularDistanciaMetros, formatarDistancia, RAIO_GEOFENCE_METROS, buscarEnderecoPorCoordenada } from '../../utils/geo';
import { mapaDeslocamentoPorVeiculo } from '../../utils/deslocamento';
import InstalarAppBanner from './InstalarAppBanner.jsx';
import { useAuth } from '../../context/AuthContext.jsx';

// Tela simples para uso dos motoristas: digitam o próprio nome e veem as
// lojas de entrega dos carregamentos feitos por eles, com um botão grande
// para registrar a chegada e, depois, a saída — o tempo de permanência na
// loja é calculado automaticamente a partir desses dois horários. Pensada
// para toque em celular/tablet, sem formulários ou campos extras.
//
// Chegada assistida por GPS: quando há alguma entrega sem chegada
// registrada e a loja tem coordenada cadastrada (Cadastros > Localização
// das Lojas), a página acompanha a posição do celular e destaca o botão
// "Registrar Chegada" quando o motorista está dentro do raio da loja — mas
// o registro continua exigindo o toque de confirmação (nunca automático
// silencioso), pra evitar um GPS impreciso registrando chegada errada.
export default function DriversPage() {
  const { state, actions, filtroTipoCarga } = useApp();
  const { grupo, perfil } = useAuth();

  // Pedido do usuário: cada motorista agora tem o próprio login, e esse
  // login deve ver só as entregas dele mesmo, sem enxergar o nome dos
  // outros motoristas. O perfil de quem logou (tabela `profiles`,
  // campo `nome` — cadastrado manualmente pelo administrador, ver
  // supabase/schema.sql) é comparado com o nome usado no carregamento; se
  // o grupo logado for 'motorista', a tela já abre direto nas entregas
  // dele, sem nenhuma lista de nomes pra escolher. Só quem loga como
  // 'administrativo' (portaria/operação) continua vendo a lista completa e
  // pode abrir qualquer motorista — inclusive no modo demonstração local
  // (sem Supabase configurado), que sempre usa grupo 'administrativo' (ver
  // App.jsx).
  //
  // Importante: isso esconde os outros nomes na TELA, mas os dados em si
  // continuam sincronizados como um único bloco pra todo mundo autenticado
  // (ver app_state em supabase/schema.sql) — não é uma restrição de acesso
  // no banco linha a linha. Pra esse travamento funcionar, o nome em
  // `profiles.nome` precisa ser exatamente igual (sem diferenciar
  // maiúsculas/minúsculas) ao nome usado nos carregamentos desse motorista.
  const nomeMotoristaLogado = grupo === 'motorista' ? (perfil?.nome || '').trim() : null;

  const [motoristaBuscado, setMotoristaBuscado] = useState(nomeMotoristaLogado || null);

  // Se o perfil ainda não tinha carregado no primeiro render (ou mudar por
  // algum motivo), mantém o motorista logado sempre travado no nome dele.
  useEffect(() => {
    if (nomeMotoristaLogado && motoristaBuscado !== nomeMotoristaLogado) {
      setMotoristaBuscado(nomeMotoristaLogado);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nomeMotoristaLogado]);
  // Filtro de texto acima da lista de motoristas — só aparece quando há
  // muitos nomes cadastrados (ver motoristasFiltrados). Não é um menu
  // suspenso: a lista inteira já fica visível na tela, o filtro só reduz
  // quais nomes aparecem nela.
  const [filtroMotorista, setFiltroMotorista] = useState('');
  const [posicaoAtual, setPosicaoAtual] = useState(null);
  // Endereço da rua já resolvido (geocodificação reversa) pra posição atual
  // do GPS — mantido em segundo plano (ver useEffect abaixo) pra já estar
  // pronto quando o motorista tocar em "Registrar Chegada/Saída", sem
  // atrasar o toque esperando a rede.
  const [enderecoAtual, setEnderecoAtual] = useState(null);
  // 'inativo' | 'buscando' | 'ativo' | 'negado' | 'indisponivel'
  const [statusLocalizacao, setStatusLocalizacao] = useState('inativo');

  // Controla o formulário de registro manual de chegada/saída (chave
  // `${entregaId}-chegada` ou `${entregaId}-saida`) — usado quando o
  // motorista esquece de tocar no botão na hora certa e alguém precisa
  // lançar o horário real depois.
  const [manualAberto, setManualAberto] = useState({});
  const [valorManual, setValorManual] = useState({});

  // Confirmação (chave `${entregaId}-chegada`/`-saida`) antes de desfazer um
  // registro feito sem querer — evita apagar chegada/saída com um toque só,
  // já que essa ação some com o registro por completo (diferente da correção
  // manual acima, que só troca o horário de algo que deveria mesmo existir).
  const [confirmandoDesfazer, setConfirmandoDesfazer] = useState(null);

  // Observação opcional (fila, recusa de carga, atraso etc.) que o motorista
  // pode deixar ao registrar a saída — guardada por entrega enquanto ele
  // ainda não confirmou, pra não se perder se ele digitar antes de tocar no
  // botão.
  const [observacaoPorEntrega, setObservacaoPorEntrega] = useState({});

  // Entregas concluídas em dias anteriores ficam escondidas atrás deste
  // interruptor por padrão — só as de hoje (e as ainda pendentes) aparecem
  // de cara, pra lista não crescer sem fim conforme o motorista acumula
  // entregas ao longo do tempo.
  const [mostrarHistorico, setMostrarHistorico] = useState(false);

  function alternarManual(chave) {
    setManualAberto((atual) => ({ ...atual, [chave]: !atual[chave] }));
    setValorManual((atual) => (atual[chave] ? atual : { ...atual, [chave]: paraDataHoraLocalInput() }));
  }

  function confirmarManual(chave, aoConfirmar) {
    aoConfirmar(deDataHoraLocalInput(valorManual[chave]));
    setManualAberto((atual) => ({ ...atual, [chave]: false }));
  }

  const lojasPorId = useMemo(() => {
    const mapa = {};
    state.lojas.forEach((l) => {
      mapa[l.id] = l;
    });
    return mapa;
  }, [state.lojas]);

  const localizacaoPorCodigo = useMemo(() => {
    const mapa = {};
    (state.localizacaoLojas || []).forEach((l) => {
      mapa[l.codigo] = l;
    });
    return mapa;
  }, [state.localizacaoLojas]);

  const entregas = useMemo(() => {
    if (!motoristaBuscado) return [];
    return state.protocolos
      .filter((p) => (p.motorista || '').trim().toLowerCase() === motoristaBuscado.toLowerCase())
      .map((p) => ({ ...p, loja: lojasPorId[p.lojaId] }))
      .filter((p) => p.loja && lojaPassaFiltroTipoCarga(p.loja, filtroTipoCarga))
      .sort((a, b) => {
        // Entregas pendentes (sem saída registrada) aparecem primeiro;
        // dentro de cada grupo, a mais recente primeiro.
        const aPendente = !a.saidaLoja;
        const bPendente = !b.saidaLoja;
        if (aPendente !== bPendente) return aPendente ? -1 : 1;
        return new Date(b.dataHora) - new Date(a.dataHora);
      });
  }, [state.protocolos, lojasPorId, motoristaBuscado, filtroTipoCarga]);

  // Separa as entregas já concluídas em dias anteriores — ficam escondidas
  // atrás do botão "Ver histórico" por padrão, pra lista de hoje não vir
  // misturada com entregas antigas conforme elas se acumulam com o tempo.
  // Pendentes e as concluídas hoje continuam sempre visíveis, na mesma
  // ordem que `entregas` já define.
  const entregasVisiveis = useMemo(
    () => entregas.filter((e) => !e.saidaLoja || eHoje(e.saidaLoja)),
    [entregas]
  );
  const entregasAntigas = useMemo(
    () => entregas.filter((e) => e.saidaLoja && !eHoje(e.saidaLoja)),
    [entregas]
  );

  // Tempo de deslocamento de cada entrega (do CD até a 1ª loja, ou de uma
  // loja até a próxima na mesma viagem — ver deslocamento.js). Agrupa por
  // placa antes de calcular porque a sequência da viagem é por veículo, não
  // por motorista (um motorista raramente troca de veículo no mesmo dia,
  // mas agrupar certo não custa nada). Não depende de um relógio "ao vivo"
  // (como o card Andamento das Entregas) — recalcula no próximo render,
  // igual à permanência na loja já mostrada aqui.
  const deslocamentoPorProtocolo = useMemo(() => {
    const agoraMs = Date.now();
    const porPlaca = {};
    entregas.forEach((e) => {
      (porPlaca[e.placa] ||= []).push(e);
    });
    const mapaFinal = new Map();
    Object.values(porPlaca).forEach((grupo) => {
      mapaDeslocamentoPorVeiculo(grupo, agoraMs).forEach((valor, chave) => mapaFinal.set(chave, valor));
    });
    return mapaFinal;
  }, [entregas]);

  // Liga o GPS sempre que houver alguma entrega em aberto (chegada ou saída
  // ainda pendente) — tanto pra destacar o botão quando a loja tem
  // coordenada cadastrada (geofence) quanto pra já ter uma posição pronta
  // pra gravar junto no momento em que o motorista tocar em "Registrar
  // Chegada"/"Registrar Saída" (ver aoRegistrar), mesmo quando a loja não
  // tem coordenada cadastrada.
  const temEntregaPendente = useMemo(() => entregas.some((e) => !e.saidaLoja), [entregas]);

  useEffect(() => {
    if (!temEntregaPendente) {
      setStatusLocalizacao('inativo');
      return undefined;
    }
    if (!navigator.geolocation) {
      setStatusLocalizacao('indisponivel');
      return undefined;
    }
    setStatusLocalizacao((atual) => (atual === 'ativo' ? atual : 'buscando'));
    const watchId = navigator.geolocation.watchPosition(
      (posicao) => {
        setPosicaoAtual({ latitude: posicao.coords.latitude, longitude: posicao.coords.longitude });
        setStatusLocalizacao('ativo');
      },
      (erro) => {
        setStatusLocalizacao(erro.code === erro.PERMISSION_DENIED ? 'negado' : 'indisponivel');
      },
      { enableHighAccuracy: true, maximumAge: 15000, timeout: 20000 }
    );
    return () => navigator.geolocation.clearWatch(watchId);
  }, [temEntregaPendente]);

  // Resolve o endereço da rua (geocodificação reversa) em segundo plano
  // sempre que a posição do GPS muda o suficiente (arredondado a ~11 m, pra
  // não disparar uma busca nova a cada tremulação do GPS parado). Guarda
  // contra resposta atrasada de uma posição antiga sobrescrever um endereço
  // mais novo (`ignorar` no cleanup). Falha silenciosa (ver
  // buscarEnderecoPorCoordenada) — sem internet ou serviço fora do ar, o
  // registro continua funcionando normalmente, só sem endereço anexado.
  useEffect(() => {
    if (!posicaoAtual) {
      setEnderecoAtual(null);
      return undefined;
    }
    let ignorar = false;
    buscarEnderecoPorCoordenada(posicaoAtual.latitude, posicaoAtual.longitude).then((endereco) => {
      if (!ignorar && endereco) setEnderecoAtual(endereco);
    });
    return () => {
      ignorar = true;
    };
  }, [
    posicaoAtual && Math.round(posicaoAtual.latitude * 10000),
    posicaoAtual && Math.round(posicaoAtual.longitude * 10000),
  ]);

  // Registra chegada/saída anexando a posição do GPS já disponível (a
  // mesma usada pro destaque do botão) — sem posição (GPS desligado, sem
  // permissão, ou ainda buscando), registra normalmente, só sem localização
  // anexada, pra nunca travar o motorista por causa disso.
  function aoRegistrar(acaoFn, protocoloId) {
    const localizacao = posicaoAtual ? { ...posicaoAtual, endereco: enderecoAtual || null } : undefined;
    acaoFn(protocoloId, undefined, localizacao);
  }

  function aoRegistrarSaida(protocoloId) {
    const localizacao = posicaoAtual ? { ...posicaoAtual, endereco: enderecoAtual || null } : undefined;
    actions.registrarSaidaLoja(protocoloId, undefined, localizacao, observacaoPorEntrega[protocoloId]);
    setObservacaoPorEntrega((atual) => ({ ...atual, [protocoloId]: '' }));
  }

  function aoDesfazer(chave, protocoloId, acaoFn) {
    acaoFn(protocoloId);
    setConfirmandoDesfazer((atual) => (atual === chave ? null : atual));
  }

  function urlMapa(localizacao) {
    return `https://www.google.com/maps?q=${localizacao.latitude},${localizacao.longitude}`;
  }

  // Pedido do usuário: em vez de um menu suspenso + botão "Buscar", a lista
  // de motoristas cadastrados já aparece inteira na tela — tocar no nome já
  // abre direto as lojas de entrega dele, sem toque extra (motoristas
  // leigos, pensado pra uso no celular).
  function selecionarMotorista(nome) {
    setMotoristaBuscado(nome);
  }

  function voltarParaLista() {
    setMotoristaBuscado(null);
    setFiltroMotorista('');
  }

  const motoristasFiltrados = useMemo(() => {
    const lista = state.motoristasCadastrados || [];
    const termo = filtroMotorista.trim().toLowerCase();
    const filtrada = termo ? lista.filter((m) => m.toLowerCase().includes(termo)) : lista;
    return [...filtrada].sort((a, b) => a.localeCompare(b, 'pt-BR'));
  }, [state.motoristasCadastrados, filtroMotorista]);

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <InstalarAppBanner />

      {!motoristaBuscado ? (
        <div className="rounded-lg border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-800">
          <h2 className="text-xl font-bold text-slate-700 dark:text-slate-200">Registro de Chegada e Saída</h2>
          <p className="mt-1.5 text-base text-slate-400 dark:text-slate-500">
            Toque no seu nome na lista para ver as lojas das suas cargas e registrar a chegada e a saída em cada uma.
          </p>

          {/* Pedido do usuário: lista de motoristas direto na tela (sem menu
              suspenso) — tocar no nome já abre as entregas dele. O filtro de
              texto só aparece quando há muitos nomes cadastrados, pra não
              virar uma lista enorme de rolar no celular sem necessidade. */}
          {(state.motoristasCadastrados || []).length > 8 && (
            <div className="relative mt-4">
              <Search size={18} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
              <input
                type="text"
                value={filtroMotorista}
                onChange={(e) => setFiltroMotorista(e.target.value)}
                placeholder="Buscar seu nome..."
                className="w-full rounded-lg border border-slate-300 bg-white py-3.5 pl-10 pr-4 text-lg text-slate-800 placeholder:text-slate-400 focus:border-totvs-500 dark:focus:border-whatsapp-500 focus:outline-none focus:ring-1 focus:ring-totvs-500 dark:focus:ring-whatsapp-500 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-100 dark:placeholder:text-slate-500"
              />
            </div>
          )}

          {motoristasFiltrados.length === 0 ? (
            <p className="mt-4 rounded-lg border border-dashed border-slate-300 bg-slate-50 p-5 text-center text-base text-slate-400 dark:border-slate-600 dark:bg-slate-900/40 dark:text-slate-500">
              {(state.motoristasCadastrados || []).length === 0
                ? 'Nenhum motorista cadastrado. Fale com a portaria/administração.'
                : 'Nenhum motorista encontrado com esse nome.'}
            </p>
          ) : (
            <div className="mt-4 space-y-2.5">
              {motoristasFiltrados.map((nome) => (
                <button
                  key={nome}
                  type="button"
                  onClick={() => selecionarMotorista(nome)}
                  className="flex w-full items-center gap-3 rounded-lg border border-slate-200 bg-white px-5 py-4 text-left text-lg font-semibold text-slate-700 shadow-sm transition-colors hover:border-totvs-300 hover:bg-totvs-50 active:bg-totvs-100 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-100 dark:hover:border-whatsapp-500 dark:hover:bg-slate-700"
                >
                  <User size={20} className="flex-shrink-0 text-slate-400 dark:text-slate-500" />
                  {nome}
                </button>
              ))}
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {/* Motorista logado com a própria conta fica travado no nome
              dele — não faz sentido (e não deve) oferecer "Trocar
              motorista" nesse caso, já que ele não pode enxergar os
              outros nomes. Só aparece pra quem loga como administrativo
              (portaria/operação), que pode mesmo abrir qualquer um. */}
          {!nomeMotoristaLogado && (
            <button
              type="button"
              onClick={voltarParaLista}
              className="flex items-center gap-1.5 text-base font-semibold text-totvs-600 hover:underline dark:text-whatsapp-400"
            >
              <ArrowLeft size={18} /> Trocar motorista
            </button>
          )}

          <div className="flex flex-wrap items-center justify-between gap-2 px-1">
            <p className="text-base font-bold text-slate-700 dark:text-slate-200">
              {motoristaBuscado} — {entregas.length} {entregas.length === 1 ? 'entrega encontrada' : 'entregas encontradas'}
            </p>
            {statusLocalizacao === 'ativo' && (
              <span className="flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400">
                <LocateFixed size={13} /> Localização ativa — detectando chegada
              </span>
            )}
            {statusLocalizacao === 'buscando' && (
              <span className="flex items-center gap-1 text-xs font-medium text-slate-400 dark:text-slate-500">
                <LocateFixed size={13} className="animate-pulse" /> Buscando localização...
              </span>
            )}
            {statusLocalizacao === 'negado' && (
              <span className="flex items-center gap-1 text-xs font-medium text-amber-600 dark:text-amber-400">
                <MapPinOff size={13} /> Ative a localização do navegador pra detectar a chegada automaticamente
              </span>
            )}
          </div>

          {entregas.length === 0 && (
            <div className="rounded-lg border border-dashed border-slate-300 bg-white p-8 text-center text-base text-slate-400 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-500">
              {nomeMotoristaLogado
                ? 'Nenhuma entrega encontrada pro seu nome ainda. Se isso não for o esperado, fale com a administração — pode ser que seu nome cadastrado no login esteja diferente do nome usado no carregamento.'
                : 'Nenhuma entrega encontrada para este motorista.'}
            </div>
          )}

          {entregasVisiveis.map((entrega) => (
            <CartaoEntrega
              key={entrega.id}
              entrega={entrega}
              deslocamento={deslocamentoPorProtocolo.get(entrega.id) || null}
              localizacaoPorCodigo={localizacaoPorCodigo}
              posicaoAtual={posicaoAtual}
              actions={actions}
              manualAberto={manualAberto}
              valorManual={valorManual}
              alternarManual={alternarManual}
              confirmarManual={confirmarManual}
              setValorManual={setValorManual}
              confirmandoDesfazer={confirmandoDesfazer}
              setConfirmandoDesfazer={setConfirmandoDesfazer}
              observacaoPorEntrega={observacaoPorEntrega}
              setObservacaoPorEntrega={setObservacaoPorEntrega}
              aoRegistrar={aoRegistrar}
              aoRegistrarSaida={aoRegistrarSaida}
              aoDesfazer={aoDesfazer}
              urlMapa={urlMapa}
            />
          ))}

          {/* Entregas concluídas em dias anteriores (ver entregasAntigas) —
              escondidas atrás deste botão por padrão, pra lista de hoje não
              crescer sem fim conforme o motorista acumula entregas com o
              tempo. */}
          {entregasAntigas.length > 0 && (
            <div>
              <button
                type="button"
                onClick={() => setMostrarHistorico((atual) => !atual)}
                className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-dashed border-slate-300 bg-white py-2.5 text-xs font-semibold text-slate-500 hover:bg-slate-50 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700"
              >
                <History size={13} />
                {mostrarHistorico
                  ? 'Esconder histórico'
                  : `Ver histórico (${entregasAntigas.length} entrega${entregasAntigas.length !== 1 ? 's' : ''} de dias anteriores)`}
                {mostrarHistorico ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
              </button>
              {mostrarHistorico && (
                <div className="mt-3 space-y-3">
                  {entregasAntigas.map((entrega) => (
                    <CartaoEntrega
                      key={entrega.id}
                      entrega={entrega}
                      deslocamento={deslocamentoPorProtocolo.get(entrega.id) || null}
                      localizacaoPorCodigo={localizacaoPorCodigo}
                      posicaoAtual={posicaoAtual}
                      actions={actions}
                      manualAberto={manualAberto}
                      valorManual={valorManual}
                      alternarManual={alternarManual}
                      confirmarManual={confirmarManual}
                      setValorManual={setValorManual}
                      confirmandoDesfazer={confirmandoDesfazer}
                      setConfirmandoDesfazer={setConfirmandoDesfazer}
                      observacaoPorEntrega={observacaoPorEntrega}
                      setObservacaoPorEntrega={setObservacaoPorEntrega}
                      aoRegistrar={aoRegistrar}
                      aoRegistrarSaida={aoRegistrarSaida}
                      aoDesfazer={aoDesfazer}
                      urlMapa={urlMapa}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Botão discreto que pede confirmação inline antes de desfazer um registro
// (ver aoDesfazer em DriversPage) — nunca usa window.confirm() porque a
// prévia de Artifact bloqueia esse tipo de diálogo silenciosamente.
function BotaoDesfazer({ chave, rotulo, confirmandoDesfazer, setConfirmandoDesfazer, aoConfirmar }) {
  if (confirmandoDesfazer === chave) {
    return (
      <span className="ml-1.5 inline-flex items-center gap-1 rounded-md border border-amber-300 bg-amber-50 px-1.5 py-0.5 text-amber-700 dark:border-amber-700 dark:bg-amber-900/40 dark:text-amber-300">
        Desfazer?
        <button
          type="button"
          onClick={aoConfirmar}
          className="rounded bg-amber-600 px-1.5 py-0.5 font-semibold text-white hover:bg-amber-700"
        >
          Sim
        </button>
        <button
          type="button"
          onClick={() => setConfirmandoDesfazer(null)}
          className="rounded px-1.5 py-0.5 font-medium text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-700"
        >
          Não
        </button>
      </span>
    );
  }
  return (
    <button
      type="button"
      onClick={() => setConfirmandoDesfazer(chave)}
      title={rotulo}
      className="ml-1.5 inline-flex items-center gap-1 text-slate-300 hover:text-red-500 dark:text-slate-600 dark:hover:text-red-400"
    >
      <Undo2 size={12} /> desfazer
    </button>
  );
}

// Cartão de uma entrega — extraído do map principal porque agora é
// renderizado em dois lugares (lista de hoje e o histórico escondido atrás
// do botão "Ver histórico").
function CartaoEntrega({
  entrega,
  deslocamento,
  localizacaoPorCodigo,
  posicaoAtual,
  actions,
  manualAberto,
  valorManual,
  alternarManual,
  confirmarManual,
  setValorManual,
  confirmandoDesfazer,
  setConfirmandoDesfazer,
  observacaoPorEntrega,
  setObservacaoPorEntrega,
  aoRegistrar,
  aoRegistrarSaida,
  aoDesfazer,
  urlMapa,
}) {
  const permanenciaMs =
    entrega.chegadaLoja && entrega.saidaLoja ? new Date(entrega.saidaLoja) - new Date(entrega.chegadaLoja) : null;
  const concluida = Boolean(entrega.saidaLoja);

  const localizacaoLoja = localizacaoPorCodigo[entrega.loja.loja];
  const distanciaMetros =
    !entrega.chegadaLoja && localizacaoLoja && posicaoAtual
      ? calcularDistanciaMetros(posicaoAtual.latitude, posicaoAtual.longitude, localizacaoLoja.latitude, localizacaoLoja.longitude)
      : null;
  const pertoDaLoja = distanciaMetros != null && distanciaMetros <= RAIO_GEOFENCE_METROS;

  return (
    <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800">
      <div className="flex items-start justify-between gap-2">
        {/* `min-w-0 flex-1`: sem isso, este bloco do título disputa espaço
            com o selo "Concluída" (flex-shrink-0) de forma imprevisível no
            `justify-between` — no celular (tela estreita), o código da loja
            ficava isolado numa linha, o selo "Concluída" ao lado dele, e o
            nome da loja caía sozinho pra linha de baixo, em vez de quebrar
            de um jeito legível. */}
        <div className="min-w-0 flex-1">
          {/* Texto corrido normal (sem `flex`) em vez de flex-wrap: um
              título "0407 — Loja Praça da Matriz" quebra palavra por
              palavra como qualquer texto, em vez de "0407" ficar isolado
              numa linha e o nome inteiro pular pra linha de baixo sozinho
              (o que acontecia no celular, com o selo "Concluída" disputando
              espaço do lado). O selo de carga (inline-flex) flui junto no
              texto e só desce de linha sozinho se não couber mais nada. */}
          <p className="text-lg font-bold leading-snug text-slate-800 dark:text-slate-100">
            <span className="font-mono">{entrega.loja.loja}</span> — {entrega.loja.nomeLoja}{' '}
            <TipoCargaBadge tipo={entrega.loja.tipoCarga} className="align-middle" />
          </p>
          <p className="mt-0.5 text-sm text-slate-400 dark:text-slate-500">
            Placa <span className="font-mono font-semibold text-slate-500 dark:text-slate-400">{entrega.placa}</span>
            {concluida && !eHoje(entrega.saidaLoja) && <> — {formatarData(entrega.saidaLoja.slice(0, 10))}</>}
          </p>
        </div>
        {concluida && (
          <span className="flex flex-shrink-0 items-center gap-1 rounded-full bg-emerald-50 px-3 py-1.5 text-sm font-semibold text-emerald-600 dark:border dark:border-current dark:bg-emerald-500/10 dark:text-emerald-300">
            <CheckCircle2 size={16} /> Concluída
          </span>
        )}
      </div>

      {(entrega.entregaNotasFiscais || entrega.chegadaLoja || entrega.saidaLoja || deslocamento) && (
        <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1.5 border-t border-slate-100 pt-3 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">
          {entrega.entregaNotasFiscais && (
            <span className="inline-flex items-center">
              NF entregue:{' '}
              <strong className="ml-1 text-slate-700 dark:text-slate-200">{formatarHora(entrega.entregaNotasFiscais)}</strong>
            </span>
          )}
          {deslocamento && (
            <span className="inline-flex items-center">
              Deslocamento:{' '}
              <strong className="ml-1 text-slate-700 dark:text-slate-200">
                {formatarDuracao(deslocamento.ms)}
                {deslocamento.emAndamento ? ' (em andamento)' : ''}
              </strong>
            </span>
          )}
          {entrega.chegadaLoja && (
            <span className="inline-flex items-center">
              Chegada:{' '}
              <strong className="ml-1 text-slate-700 dark:text-slate-200">{formatarHora(entrega.chegadaLoja)}</strong>
              {entrega.localizacaoChegada && (
                <a
                  href={urlMapa(entrega.localizacaoChegada)}
                  target="_blank"
                  rel="noreferrer"
                  title="Abrir no mapa"
                  className="ml-1.5 inline-flex items-center gap-1 text-totvs-600 hover:underline dark:text-whatsapp-400"
                >
                  <MapPin size={11} className="flex-shrink-0" />
                  {entrega.localizacaoChegada.endereco || 'mapa'}
                </a>
              )}
              {/* Só oferece desfazer a chegada enquanto a saída ainda não foi
                  registrada — não faz sentido "não ter chegado" numa entrega
                  que já saiu. */}
              {!concluida && (
                <BotaoDesfazer
                  chave={`${entrega.id}-chegada`}
                  rotulo="Desfazer chegada (registrado sem querer)"
                  confirmandoDesfazer={confirmandoDesfazer}
                  setConfirmandoDesfazer={setConfirmandoDesfazer}
                  aoConfirmar={() => aoDesfazer(`${entrega.id}-chegada`, entrega.id, actions.desfazerChegadaLoja)}
                />
              )}
            </span>
          )}
          {entrega.saidaLoja && (
            <span className="inline-flex items-center">
              Saída:{' '}
              <strong className="ml-1 text-slate-700 dark:text-slate-200">{formatarHora(entrega.saidaLoja)}</strong>
              {entrega.localizacaoSaida && (
                <a
                  href={urlMapa(entrega.localizacaoSaida)}
                  target="_blank"
                  rel="noreferrer"
                  title="Abrir no mapa"
                  className="ml-1.5 inline-flex items-center gap-1 text-totvs-600 hover:underline dark:text-whatsapp-400"
                >
                  <MapPin size={11} className="flex-shrink-0" />
                  {entrega.localizacaoSaida.endereco || 'mapa'}
                </a>
              )}
              <BotaoDesfazer
                chave={`${entrega.id}-saida`}
                rotulo="Desfazer saída (registrado sem querer)"
                confirmandoDesfazer={confirmandoDesfazer}
                setConfirmandoDesfazer={setConfirmandoDesfazer}
                aoConfirmar={() => aoDesfazer(`${entrega.id}-saida`, entrega.id, actions.desfazerSaidaLoja)}
              />
            </span>
          )}
          {permanenciaMs != null && (
            <span>
              Permanência:{' '}
              <strong className="text-slate-700 dark:text-slate-200">{formatarDuracao(permanenciaMs)}</strong>
            </span>
          )}
        </div>
      )}

      {entrega.observacaoSaida && (
        <p className="mt-2 flex items-start gap-1.5 rounded-md bg-amber-50 px-2 py-1.5 text-xs text-amber-700 dark:bg-amber-950/20 dark:text-amber-300">
          <MessageSquareText size={13} className="mt-px flex-shrink-0" />
          {entrega.observacaoSaida}
        </p>
      )}

      {!concluida && (
        <div className="mt-3">
          {!entrega.chegadaLoja ? (
            <>
              {pertoDaLoja && (
                <p className="mb-1.5 flex items-center justify-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  <LocateFixed size={13} /> Você está na loja ({formatarDistancia(distanciaMetros)}) — confirme a chegada
                </p>
              )}
              <button
                onClick={() => aoRegistrar(actions.registrarChegadaLoja, entrega.id)}
                className={`flex w-full items-center justify-center gap-2 rounded-lg px-4 py-4 text-lg font-semibold text-white transition-colors ${
                  pertoDaLoja
                    ? 'animate-pulse bg-emerald-600 ring-4 ring-emerald-300 hover:bg-emerald-700 active:bg-emerald-800 dark:ring-emerald-700/60'
                    : 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800'
                }`}
              >
                <LogIn size={22} /> Registrar Chegada na Loja
              </button>
              {!pertoDaLoja && distanciaMetros != null && (
                <p className="mt-1.5 text-center text-[11px] text-slate-400 dark:text-slate-500">
                  Você está a {formatarDistancia(distanciaMetros)} da loja
                </p>
              )}
              <RegistroManual
                chave={`${entrega.id}-chegada`}
                aberto={Boolean(manualAberto[`${entrega.id}-chegada`])}
                valor={valorManual[`${entrega.id}-chegada`]}
                aoAlternar={alternarManual}
                aoMudarValor={(chave, valor) => setValorManual((atual) => ({ ...atual, [chave]: valor }))}
                aoConfirmar={(chave) => confirmarManual(chave, (dataHora) => actions.registrarChegadaLoja(entrega.id, dataHora))}
                rotulo="Motorista esqueceu de registrar a chegada? Informar horário manualmente"
              />
            </>
          ) : (
            <>
              {/* Observação opcional — não bloqueia o registro da saída, só
                  fica junto se o motorista quiser deixar algum relato (fila,
                  recusa de carga, atraso etc.), visível depois no relatório
                  de Tempo de Permanência. */}
              <textarea
                value={observacaoPorEntrega[entrega.id] || ''}
                onChange={(evento) =>
                  setObservacaoPorEntrega((atual) => ({ ...atual, [entrega.id]: evento.target.value }))
                }
                placeholder="Alguma observação? (opcional — fila, atraso, recusa de carga...)"
                rows={2}
                className="mb-2 w-full resize-none rounded-lg border border-slate-200 bg-white px-3 py-2 text-base text-slate-700 placeholder:text-slate-400 focus:border-totvs-400 dark:focus:border-whatsapp-400 focus:outline-none dark:border-slate-600 dark:bg-slate-900 dark:text-slate-200 dark:placeholder:text-slate-500"
              />
              <button
                onClick={() => aoRegistrarSaida(entrega.id)}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-amber-600 px-4 py-4 text-lg font-semibold text-white transition-colors hover:bg-amber-700 active:bg-amber-800"
              >
                <LogOut size={22} /> Registrar Saída da Loja
              </button>
              <RegistroManual
                chave={`${entrega.id}-saida`}
                aberto={Boolean(manualAberto[`${entrega.id}-saida`])}
                valor={valorManual[`${entrega.id}-saida`]}
                aoAlternar={alternarManual}
                aoMudarValor={(chave, valor) => setValorManual((atual) => ({ ...atual, [chave]: valor }))}
                aoConfirmar={(chave) => confirmarManual(chave, (dataHora) => actions.registrarSaidaLoja(entrega.id, dataHora))}
                rotulo="Motorista esqueceu de registrar a saída? Informar horário manualmente"
              />
            </>
          )}
        </div>
      )}
    </div>
  );
}

// Link discreto que abre um pequeno formulário com um <input
// type="datetime-local"> — cobre o caso de o motorista esquecer de tocar
// no botão de chegada/saída na hora certa: alguém (o próprio motorista
// depois, ou a portaria) informa o horário real e registra retroativamente.
function RegistroManual({ chave, aberto, valor, aoAlternar, aoMudarValor, aoConfirmar, rotulo }) {
  return (
    <div className="mt-2">
      <button
        type="button"
        onClick={() => aoAlternar(chave)}
        className="flex w-full items-center justify-center gap-1 py-1 text-center text-[11px] font-medium text-slate-400 underline decoration-dotted underline-offset-2 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300"
      >
        <Clock size={11} /> {aberto ? 'Cancelar registro manual' : rotulo}
      </button>
      {aberto && (
        // Empilha input + botão no celular (tela estreita) em vez de lado a
        // lado: o controle nativo de data/hora já ocupa bastante espaço
        // sozinho, e espremido ao lado do botão "Confirmar" numa única linha
        // ficava difícil de ler e tocar certo. A partir de `sm` (telas
        // maiores) volta a ficar lado a lado, já que aí sobra espaço de
        // verdade pros dois.
        <div className="mt-1.5 flex flex-col gap-2 rounded-lg border border-dashed border-slate-300 bg-slate-50 p-2 dark:border-slate-600 dark:bg-slate-900/40 sm:flex-row sm:items-center">
          <input
            type="datetime-local"
            value={valor || ''}
            onChange={(evento) => aoMudarValor(chave, evento.target.value)}
            className="w-full min-w-0 rounded-md border border-slate-300 bg-white px-2 py-1.5 text-sm text-slate-700 focus:border-totvs-500 dark:focus:border-whatsapp-500 focus:outline-none focus:ring-1 focus:ring-totvs-500 dark:focus:ring-whatsapp-500 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200 sm:flex-1"
          />
          <button
            type="button"
            disabled={!valor}
            onClick={() => aoConfirmar(chave)}
            className="w-full flex-shrink-0 rounded-md bg-slate-700 px-3 py-2 text-sm font-semibold text-white transition-colors hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-40 dark:bg-slate-600 dark:hover:bg-slate-500 sm:w-auto sm:py-1.5 sm:text-xs"
          >
            Confirmar
          </button>
        </div>
      )}
    </div>
  );
}
