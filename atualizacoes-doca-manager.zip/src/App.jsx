import React, { Suspense, lazy, useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import Sidebar from './components/Layout/Sidebar.jsx';
import Header from './components/Layout/Header.jsx';
import ConnectionStatus from './components/Layout/ConnectionStatus.jsx';
import LoginPage from './components/Auth/LoginPage.jsx';
import TelaCarregando from './components/Auth/TelaCarregando.jsx';
import AcessoNegado from './components/Auth/AcessoNegado.jsx';
import { useAuth } from './context/AuthContext.jsx';
import { SUPABASE_CONFIGURADO } from './lib/supabaseClient';

// Cada aba agora só é baixada quando o usuário realmente abre ela (em vez de
// tudo entrar no mesmo arquivo .js inicial) — o Vite/React separa cada uma
// num pedaço (chunk) próprio, carregado sob demanda. Isso reduz bastante o
// tamanho do carregamento inicial do app (o chunk principal vinha passando
// dos 900kB, o que o próprio Vite avisa no build), já que a maior parte do
// código de abas como Relatórios ou Agrupamento não é necessária só para
// abrir o app e ver a tela de Box / Frota, que é a aba inicial.
const Dashboard = lazy(() => import('./components/Dashboard/Dashboard.jsx'));
const DataImport = lazy(() => import('./components/Import/DataImport.jsx'));
const BoxGrid = lazy(() => import('./components/Boxes/BoxGrid.jsx'));
const GroupingPage = lazy(() => import('./components/Grouping/GroupingPage.jsx'));
const LoadingPage = lazy(() => import('./components/Loading/LoadingPage.jsx'));
const DriversPage = lazy(() => import('./components/Drivers/DriversPage.jsx'));
const ReportsPage = lazy(() => import('./components/Reports/ReportsPage.jsx'));
const RegistrationsPage = lazy(() => import('./components/Registrations/RegistrationsPage.jsx'));

// Indicador leve mostrado só durante a curta espera do download do chunk da
// aba (geralmente imperceptível numa conexão normal, mas evita a tela ficar
// em branco caso demore) — diferente da TelaCarregando de tela cheia usada
// no carregamento inicial da sessão/login, este fica contido dentro da área
// de conteúdo, sem empurrar o cabeçalho/menu.
function CarregandoAba() {
  return (
    <div className="flex h-64 items-center justify-center text-slate-400 dark:text-slate-500">
      <Loader2 size={24} className="animate-spin" />
    </div>
  );
}

// `grupos` lista quem pode ver cada aba — motorista só tem acesso à tela
// que ele realmente usa no dia a dia (registrar chegada/saída);
// administrativo tem acesso total, incluindo operação, relatórios,
// cadastros e importação de dados.
//
// A aba Dashboard fica oculta do menu por escolha do usuário (o
// componente/rota continuam existindo em renderConteudo, caso precise
// voltar — basta reinserir a entrada aqui). "Box / Frota" é a primeira
// da lista de propósito: é ela que abre por padrão ao entrar no app (ver
// useEffect logo abaixo, que sempre cai na primeira aba permitida).
export const ABAS = [
  { chave: 'boxes', rotulo: 'Box / Frota', grupos: ['administrativo'] },
  { chave: 'agrupamento', rotulo: 'Expedição / Processos', grupos: ['administrativo'] },
  { chave: 'carregamento', rotulo: 'Carregamento / Faturamento', grupos: ['administrativo'] },
  { chave: 'motoristas', rotulo: 'Motoristas', grupos: ['motorista', 'administrativo'] },
  { chave: 'relatorios', rotulo: 'Relatórios', grupos: ['administrativo'] },
  { chave: 'cadastros', rotulo: 'Cadastros', grupos: ['administrativo'] },
  { chave: 'importar', rotulo: 'Importar Dados', grupos: ['administrativo'] },
];

function AppLogado({ grupo }) {
  const abasPermitidas = ABAS.filter((a) => a.grupos.includes(grupo));
  const [abaAtiva, setAbaAtiva] = useState(null);
  // O menu lateral começa sempre fechado — só abre quando o usuário clica
  // no botão de menu do cabeçalho (ver Header.jsx) — e fecha sozinho ao
  // escolher uma aba ou clicar fora dele.
  const [menuAberto, setMenuAberto] = useState(false);

  // A aba inicial depende do grupo (só sabido depois do login), e se o
  // grupo mudar (ou a aba atual deixar de ser permitida por algum motivo)
  // sempre cai de volta pra primeira aba que esse grupo pode ver.
  useEffect(() => {
    if (!abasPermitidas.some((a) => a.chave === abaAtiva)) {
      setAbaAtiva(abasPermitidas[0]?.chave ?? null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [grupo]);

  function renderConteudo() {
    switch (abaAtiva) {
      case 'dashboard':
        return <Dashboard irPara={setAbaAtiva} />;
      case 'importar':
        return <DataImport />;
      case 'boxes':
        // Clicar numa loja dentro de um box leva pra aba Agrupamento &
        // Etiquetas (onde ficam as ações daquela loja — etiquetas, mover,
        // concluir), sem abrir nenhuma tela por cima automaticamente.
        return <BoxGrid irPara={setAbaAtiva} aoAbrirAgrupamento={() => setAbaAtiva('agrupamento')} />;
      case 'agrupamento':
        return <GroupingPage irPara={setAbaAtiva} />;
      case 'carregamento':
        return <LoadingPage irPara={setAbaAtiva} />;
      case 'motoristas':
        return <DriversPage />;
      case 'relatorios':
        return <ReportsPage />;
      case 'cadastros':
        return <RegistrationsPage />;
      default:
        return null;
    }
  }

  if (!abaAtiva) return <TelaCarregando />;

  return (
    <div className="flex h-screen w-full overflow-hidden bg-slate-100 dark:bg-slate-900">
      <Sidebar
        abas={abasPermitidas}
        abaAtiva={abaAtiva}
        setAbaAtiva={setAbaAtiva}
        aberto={menuAberto}
        aoFechar={() => setMenuAberto(false)}
      />
      <div className="flex min-w-0 flex-1 flex-col">
        <Header
          tituloAba={ABAS.find((a) => a.chave === abaAtiva)?.rotulo}
          abaAtiva={abaAtiva}
          onAbrirMenu={() => setMenuAberto(true)}
        />
        <main className="flex-1 overflow-y-auto p-3 sm:p-4 lg:p-6">
          {/* Na aba Box / Frota, o conteúdo preenche toda a altura
              disponível (h-full) e se organiza em flex-col internamente, pra
              a lista de veículos do card "Andamento das Entregas" ganhar
              rolagem própria dentro do espaço que sobra — em vez de a
              página inteira precisar rolar. Nas outras abas o wrapper
              continua sem altura fixa, do jeito que sempre foi.

              A largura máxima do conteúdo cresce um pouco em telas bem
              grandes (2xl — monitores grandes/TV) em vez de ficar sempre
              travada em max-w-7xl (1280px): sem isso, sobrava muita área
              escura vazia nas laterais numa TV/monitor 4K, sem nenhum
              ganho de legibilidade. */}
          <div className={`mx-auto max-w-7xl 2xl:max-w-[1600px] ${abaAtiva === 'boxes' ? 'h-full' : ''}`}>
            <Suspense fallback={<CarregandoAba />}>{renderConteudo()}</Suspense>
          </div>
        </main>
      </div>

      {/* O menu lateral agora é sempre uma gaveta fechada por padrão (em
          qualquer tamanho de tela), então o indicador de conexão que antes
          morava no rodapé da sidebar fixa do desktop precisa de uma versão
          flutuante própria, sempre visível no canto inferior esquerdo. */}
      <div className="fixed bottom-3 left-3 z-30 rounded-full border border-slate-200 bg-white px-3 py-1.5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
        <ConnectionStatus />
      </div>
    </div>
  );
}

// Porta de entrada do app: sem Supabase configurado (ex: o preview do
// claude.ai, que não tem variáveis de ambiente), o app abre direto em modo
// demonstração, com acesso total e sem exigir login — exatamente como
// sempre funcionou antes de existir autenticação. Com Supabase configurado
// (o site publicado no Vercel), passa a exigir login de verdade: tela de
// carregamento (checando sessão ou buscando o perfil), tela de login,
// acesso negado (login válido mas sem grupo liberado) ou o app — nessa
// ordem.
export default function App() {
  const { carregando, usuario, grupo, erroPerfil } = useAuth();

  if (!SUPABASE_CONFIGURADO) return <AppLogado grupo="administrativo" />;
  if (carregando) return <TelaCarregando texto={usuario ? 'Carregando seu perfil...' : 'Verificando sessão...'} />;
  if (!usuario) return <LoginPage />;
  if (erroPerfil) return <AcessoNegado mensagem={erroPerfil} />;
  if (!grupo) return <TelaCarregando texto="Carregando seu perfil..." />;

  return <AppLogado grupo={grupo} />;
}
